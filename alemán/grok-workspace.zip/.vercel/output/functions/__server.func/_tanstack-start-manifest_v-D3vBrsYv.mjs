//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D3vBrsYv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/notes",
			"/prints",
			"/work",
			"/writing"
		],
		preloads: ["/assets/index-BGRievJK.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BGRievJK.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Ir4c7Ejq.js"]
	},
	"/notes": {
		filePath: "/workspace/src/routes/notes.tsx",
		children: void 0,
		preloads: ["/assets/notes-DhdMPUg9.js", "/assets/button-B-G39Aew.js"]
	},
	"/prints": {
		filePath: "/workspace/src/routes/prints.tsx",
		children: void 0,
		preloads: ["/assets/prints-z9-WDNA3.js", "/assets/button-B-G39Aew.js"]
	},
	"/work": {
		filePath: "/workspace/src/routes/work.tsx",
		children: void 0,
		preloads: ["/assets/work-BCfKTUaF.js"]
	},
	"/writing": {
		filePath: "/workspace/src/routes/writing.tsx",
		children: void 0,
		preloads: ["/assets/writing-BWP4DUKV.js"]
	}
} });
//#endregion
export { tsrStartManifest };
