import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SiteChrome } from "./router-DCf7GV2S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/writing-BKmPpu5J.js
var import_jsx_runtime = require_jsx_runtime();
function WritingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteChrome, {
		back: true,
		wide: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "max-w-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Essay · March 2026"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-3xl leading-tight tracking-tight",
					children: "The Hour After Rain"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-subtle",
					children: "Avery Lin · Portland"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 space-y-5 text-base leading-relaxed text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The city does not end when the rain does. It waits." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "On Burnside the asphalt holds the last of the storm in a long, dark sheet. Storefronts come back in pieces: a neon Open, a stack of chairs, the yellow of a taxi that has not yet decided to move. I walk the block twice. The first time I am looking for a picture. The second time I am trying to remember why the first one was not enough." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Photographers talk about golden hour as if it were a promise. I prefer this one — the hour after rain — because nothing in it is trying to be beautiful. The light is leftover. The streets are honest. A bus sighs at the corner and throws a ribbon of red across the wet. That is the whole event." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I used to wait for people to leave the frame. Now I wait for them to become part of the weather. A coat, a reflection, a small decision to keep walking. The picture is not of them. It is of the pause they walk through." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "If you live in a wet city you already know this hour. It is the one that smells like stone and metal. It is the one that makes you late, because you keep stopping." })
					]
				})
			]
		})
	});
}
//#endregion
export { WritingPage as component };
