import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SiteChrome } from "./router-DCf7GV2S.mjs";
import { t as Button } from "./button-BcsKAaku.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notes-C2nf826J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_KEY = "avery-notes-email";
function NotesPage() {
	const [email, setEmail] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [joined, setJoined] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			if (localStorage.getItem(STORAGE_KEY)) setJoined(true);
		} catch {}
	}, []);
	function onSubmit(event) {
		event.preventDefault();
		const value = email.trim().toLowerCase();
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
			setError("Enter a valid email address.");
			return;
		}
		try {
			localStorage.setItem(STORAGE_KEY, value);
		} catch {}
		setError("");
		setJoined(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteChrome, {
		back: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Field notes"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl leading-tight tracking-tight",
				children: "A letter, once a month"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-pretty text-muted",
				children: "New pictures, a few sentences, and the weather where they were made. Nothing to sell you. Unsubscribe whenever you like."
			}),
			joined ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 rounded-xl border border-border bg-surface px-4 py-5 text-sm leading-relaxed text-fg",
				role: "status",
				children: "You’re on the list. The next note goes out at the start of the month."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 flex flex-col gap-3",
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium text-fg",
						htmlFor: "notes-email",
						children: "Email"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "notes-email",
						type: "email",
						name: "email",
						autoComplete: "email",
						required: true,
						value: email,
						onChange: (event) => {
							setEmail(event.target.value);
							if (error) setError("");
						},
						placeholder: "you@example.com",
						"aria-invalid": error ? true : void 0,
						"aria-describedby": error ? "notes-error" : void 0,
						className: "h-11 rounded-md border border-border bg-surface px-3 text-base text-fg outline-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-accent/60"
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: "notes-error",
						className: "text-sm text-muted",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "mt-1 w-full",
						children: "Subscribe"
					})
				]
			})
		]
	});
}
//#endregion
export { NotesPage as component };
