import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as MapPin, p as ArrowUpRight, u as ChevronRight } from "../_libs/lucide-react.mjs";
import { a as profile, c as cn, n as SiteChrome, o as socials, r as featured } from "./router-DCf7GV2S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-WwAfSUjy.js
var import_jsx_runtime = require_jsx_runtime();
var linkClass = [
	"group flex min-h-16 items-center gap-3.5 rounded-2xl border border-border bg-surface",
	"px-3.5 py-3 text-left",
	"transition-[transform,border-color,background-color] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
	"hover:-translate-y-px hover:border-fg/20",
	"active:scale-[0.96]",
	"focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 focus-visible:ring-offset-2 focus-visible:ring-offset-bg"
].join(" ");
function FeaturedLink({ item, delay }) {
	const Icon = item.icon;
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-10 shrink-0 place-items-center rounded-md bg-bg text-fg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-4",
				strokeWidth: 1.75
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-medium leading-snug text-fg",
				children: item.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-sm leading-snug text-muted",
				children: item.subtitle
			})]
		}),
		item.external ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
			className: "size-4 shrink-0 text-subtle transition-transform duration-[var(--motion-quick)] ease-[var(--ease-out)] group-hover:translate-x-0.5 group-hover:-translate-y-0.5",
			strokeWidth: 1.75
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
			className: "size-4 shrink-0 text-subtle transition-transform duration-[var(--motion-quick)] ease-[var(--ease-out)] group-hover:translate-x-0.5",
			strokeWidth: 1.75
		})
	] });
	const style = { animationDelay: `calc(${delay} * var(--motion-stagger))` };
	if (item.external) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: item.href,
		className: cn(linkClass, "rise-in"),
		style,
		children: inner
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: item.href,
		className: cn(linkClass, "rise-in"),
		style,
		children: inner
	});
}
function XMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M18.244 2H21l-6.51 7.44L22 22h-6.79l-4.73-6.18L5.2 22H2.44l6.96-7.96L2 2h6.91l4.27 5.66L18.24 2Zm-1.19 18.2h1.88L7.03 3.7H5.02l12.03 16.5Z"
		})
	});
}
function SocialLinks({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: cn("flex items-center justify-center gap-2.5", className),
		children: socials.map((item) => {
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: item.href,
				target: item.href.startsWith("mailto:") ? void 0 : "_blank",
				rel: item.href.startsWith("mailto:") ? void 0 : "noreferrer noopener",
				"aria-label": item.label,
				className: cn("grid size-11 place-items-center rounded-full border border-border bg-surface text-fg", "transition-[transform,border-color,background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]", "hover:-translate-y-px hover:border-fg/25", "active:scale-[0.96]", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 focus-visible:ring-offset-2 focus-visible:ring-offset-bg"),
				children: Icon === "x" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(XMark, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-4",
					strokeWidth: 1.75
				})
			}) }, item.label);
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteChrome, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rise-in rounded-full bg-accent/30 p-1",
					style: { animationDelay: "calc(0 * var(--motion-stagger))" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: profile.avatar,
						alt: `${profile.name}, ${profile.role}`,
						width: 112,
						height: 112,
						className: "size-28 rounded-full object-cover object-[center_20%] bg-surface"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "rise-in mt-6 font-display text-3xl leading-tight tracking-tight text-fg",
					style: { animationDelay: "calc(1 * var(--motion-stagger))" },
					children: profile.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rise-in mt-1 text-sm text-muted",
					style: { animationDelay: "calc(2 * var(--motion-stagger))" },
					children: [
						profile.handle,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-1.5 text-subtle",
							"aria-hidden": "true",
							children: "·"
						}),
						profile.role
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise-in mt-4 max-w-sm text-pretty text-base leading-normal text-muted",
					style: { animationDelay: "calc(3 * var(--motion-stagger))" },
					children: profile.bio
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rise-in mt-4 inline-flex items-center gap-1.5 text-sm text-subtle",
					style: { animationDelay: "calc(4 * var(--motion-stagger))" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
						className: "size-3.5",
						strokeWidth: 1.75
					}), profile.location]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise-in mt-4 rounded-full border border-border px-3 py-1 text-xs font-medium tracking-wide text-muted",
					style: { animationDelay: "calc(5 * var(--motion-stagger))" },
					children: profile.status
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rise-in mt-6",
					style: { animationDelay: "calc(6 * var(--motion-stagger))" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialLinks, {})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "mt-8 flex flex-col gap-3",
			"aria-label": "Featured links",
			children: featured.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedLink, {
				item,
				delay: 7 + index
			}, item.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-10 text-center text-xs text-subtle",
			children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" ",
				profile.name
			]
		})
	] });
}
//#endregion
export { Home as component };
