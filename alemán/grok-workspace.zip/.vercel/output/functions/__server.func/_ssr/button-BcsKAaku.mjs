import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { c as cn } from "./router-DCf7GV2S.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-BcsKAaku.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva([
	"inline-flex items-center justify-center gap-2 whitespace-nowrap",
	"rounded-md text-sm font-medium",
	"transition-[transform,background-color,color,opacity,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
	"focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 focus-visible:ring-offset-2 focus-visible:ring-offset-bg",
	"disabled:pointer-events-none disabled:opacity-50",
	"active:not-disabled:scale-[0.96]"
].join(" "), {
	variants: {
		variant: {
			default: "bg-fg text-bg hover:opacity-90",
			outline: "border border-border bg-surface text-fg hover:border-fg/25 hover:bg-bg",
			ghost: "text-fg hover:bg-surface"
		},
		size: {
			default: "h-11 px-4",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { Button as t };
