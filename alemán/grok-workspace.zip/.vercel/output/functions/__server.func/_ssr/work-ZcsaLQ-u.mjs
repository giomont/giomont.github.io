import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SiteChrome, s as works } from "./router-DCf7GV2S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/work-ZcsaLQ-u.js
var import_jsx_runtime = require_jsx_runtime();
function WorkPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteChrome, {
		back: true,
		wide: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Selected work"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl leading-tight tracking-tight",
					children: "Photographs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-pretty text-muted",
					children: "Analog frames from wet streets, fogged water, and the hour a room turns toward night."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-10 flex flex-col gap-10",
			children: works.map((work) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: work.src,
					alt: work.alt,
					className: "aspect-[4/3] w-full object-cover transition-transform duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)] hover:scale-[1.02]"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
				className: "mt-3 flex items-baseline justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-fg",
					children: work.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: work.place
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tabular-nums text-subtle",
					children: work.year
				})]
			})] }) }, work.src))
		})]
	});
}
//#endregion
export { WorkPage as component };
