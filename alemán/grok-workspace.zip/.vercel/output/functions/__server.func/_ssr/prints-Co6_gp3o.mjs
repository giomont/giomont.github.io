import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as profile, i as prints, n as SiteChrome, s as works } from "./router-DCf7GV2S.mjs";
import { t as Button } from "./button-BcsKAaku.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/prints-Co6_gp3o.js
var import_jsx_runtime = require_jsx_runtime();
function PrintsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteChrome, {
		back: true,
		wide: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Print shop"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl leading-tight tracking-tight",
					children: "Limited editions"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-pretty text-muted",
					children: "Archival pigment on cotton rag. Signed, numbered, and shipped from Portland."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-10 flex flex-col gap-8",
			children: prints.map((print) => {
				const work = works[print.workIndex];
				if (!work) return null;
				const subject = encodeURIComponent(`Print inquiry: ${work.title}`);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "overflow-hidden rounded-2xl border border-border bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: work.src,
						alt: work.alt,
						className: "aspect-[4/3] w-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 p-4 sm:flex-row sm:items-end sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-fg",
								children: work.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									print.size,
									" · ",
									print.edition
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm tabular-nums text-fg",
								children: print.price
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${profile.email}?subject=${subject}`,
								children: "Inquire"
							})
						})]
					})]
				}, work.src);
			})
		})]
	});
}
//#endregion
export { PrintsPage as component };
