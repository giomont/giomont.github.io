import { createFileRoute } from "@tanstack/react-router";
import { ClassSession } from "@/components/class/session";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "Klasse 20" },
      {
        name: "description",
        content:
          "20 minutos de alemán con juegos: saludos, memoria, der/die/das, frases y relámpago.",
      },
    ],
  }),
});

function Home() {
  return <ClassSession />;
}
