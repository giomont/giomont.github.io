import { createRouter } from "@tanstack/react-router";
import { AppErrorComponent } from "@/lib/error-component";
import { routeTree } from "./routeTree.gen";

function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center bg-bg px-6 text-center text-fg">
      <h1 className="font-display text-3xl tracking-tight">No está aquí</h1>
      <p className="mt-3 max-w-sm text-pretty text-muted">
        Vuelve a la clase. El reloj sigue en la pizarra.
      </p>
      <a
        href="/"
        className="mt-6 text-sm font-medium text-fg underline-offset-4 hover:underline"
      >
        Klasse 20
      </a>
    </main>
  );
}

export function getRouter() {
  return createRouter({
    routeTree,
    defaultErrorComponent: AppErrorComponent,
    defaultNotFoundComponent: NotFound,
  });
}
