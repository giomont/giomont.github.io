import { useEffect, useMemo, useRef, useState } from "react";
import { blitzItems } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";
import { speakGerman } from "@/lib/speak";
import { formatClock, shuffle } from "@/lib/utils";
import { ChoiceGrid } from "@/components/class/choice-grid";

const ROUND = 60;

export function GameBlitz({ onDone }: { onDone: () => void }) {
  const markAnswer = useClassStore((s) => s.markAnswer);
  const paused = useClassStore((s) => s.paused);
  const deck = useMemo(
    () =>
      shuffle(blitzItems).map((item) => ({
        ...item,
        options: uniqueOptions(item.options, item.answer),
      })),
    [],
  );
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [left, setLeft] = useState(ROUND);
  const doneRef = useRef(false);
  const item = deck[index % deck.length];

  useEffect(() => {
    let frame = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.1);
      last = now;
      if (!paused && !doneRef.current) {
        setLeft((value) => {
          const next = value - dt;
          if (next <= 0) {
            if (!doneRef.current) {
              doneRef.current = true;
              onDone();
            }
            return 0;
          }
          return next;
        });
      }
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [paused, onDone]);

  if (!item) return null;

  function pick(option: string) {
    if (picked || !item || doneRef.current) return;
    const ok = option === item.answer;
    setPicked(option);
    markAnswer(ok, ok ? 8 + Math.floor(left / 12) : 0);
    if (ok) speakGerman(item.speak);
    window.setTimeout(() => {
      if (doneRef.current) return;
      setPicked(null);
      setIndex((n) => n + 1);
    }, 380);
  }

  return (
    <div>
      <div className="flex items-end justify-between gap-3">
        <p className="text-sm text-muted">Español → alemán</p>
        <p className="font-display text-2xl tabular-nums leading-none">
          {formatClock(left)}
        </p>
      </div>
      <h2 className="mt-4 font-display text-3xl leading-tight tracking-tight">
        {item.prompt}
      </h2>
      <div className="mt-6">
        <ChoiceGrid
          options={item.options}
          locked={picked !== null}
          picked={picked}
          correct={item.answer}
          onPick={pick}
        />
      </div>
    </div>
  );
}

function uniqueOptions(options: string[], answer: string) {
  const unique = Array.from(new Set(options));
  if (!unique.includes(answer)) unique.unshift(answer);
  return shuffle(unique).slice(0, 4);
}
