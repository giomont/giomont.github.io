import { Hud } from "@/components/class/hud";
import { BetweenScreen } from "@/components/class/between-screen";
import { EndScreen } from "@/components/class/end-screen";
import { GameBlitz } from "@/components/class/game-blitz";
import { GameGender } from "@/components/class/game-gender";
import { GameGreetings } from "@/components/class/game-greetings";
import { GameMemory } from "@/components/class/game-memory";
import { GameScramble } from "@/components/class/game-scramble";
import { StartScreen } from "@/components/class/start-screen";
import { Button } from "@/components/ui/button";
import { GAMES } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";
import { useRafClock } from "@/lib/use-raf-clock";

export function ClassSession() {
  useRafClock();
  const status = useClassStore((s) => s.status);
  const gameIndex = useClassStore((s) => s.gameIndex);
  const round = useClassStore((s) => s.round);
  const paused = useClassStore((s) => s.paused);
  const completeGame = useClassStore((s) => s.completeGame);
  const togglePause = useClassStore((s) => s.togglePause);

  if (status === "idle") return <StartScreen />;
  if (status === "done") return <EndScreen />;

  const game = GAMES[Math.min(gameIndex, GAMES.length - 1)];

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Hud />
      {status === "between" ? (
        <BetweenScreen />
      ) : (
        <main className="mx-auto w-full max-w-lg px-5 py-6 pb-16">
          <p className="text-sm text-muted">{game?.blurb}</p>
          <div className="mt-5">
            {game?.id === "greetings" ? (
              <GameGreetings onDone={completeGame} />
            ) : null}
            {game?.id === "memory" ? (
              <GameMemory onDone={completeGame} />
            ) : null}
            {game?.id === "gender" ? (
              <GameGender onDone={completeGame} />
            ) : null}
            {game?.id === "scramble" ? (
              <GameScramble onDone={completeGame} />
            ) : null}
            {game?.id === "blitz" ? (
              <GameBlitz key={round} onDone={completeGame} />
            ) : null}
          </div>
          <button
            type="button"
            onClick={completeGame}
            className="mt-10 text-sm text-subtle underline-offset-4 hover:text-muted hover:underline"
          >
            Saltar este juego
          </button>
        </main>
      )}
      {paused ? (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-fg/70 px-6">
          <div className="w-full max-w-sm rounded-2xl bg-bg p-6 text-fg">
            <h2 className="font-display text-2xl">Pausa</h2>
            <p className="mt-2 text-sm text-muted">
              El reloj de la clase está detenido.
            </p>
            <Button className="mt-6 w-full" onClick={togglePause}>
              Seguir
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
