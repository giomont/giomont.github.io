import { useMemo, useState } from "react";
import { genderItems } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";
import { speakGerman } from "@/lib/speak";
import { cn, shuffle } from "@/lib/utils";
import { SpeakButton } from "@/components/class/speak-button";

const ARTICLES = ["der", "die", "das"] as const;

export function GameGender({ onDone }: { onDone: () => void }) {
  const markAnswer = useClassStore((s) => s.markAnswer);
  const streak = useClassStore((s) => s.streak);
  const items = useMemo(() => shuffle(genderItems), []);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const item = items[index];

  if (!item) return null;

  function pick(article: string) {
    if (picked || !item) return;
    const ok = article === item.article;
    setPicked(article);
    markAnswer(ok, ok ? 12 + streak * 2 : 0);
    speakGerman(`${ok ? item.article : item.article} ${item.word}`);
    window.setTimeout(() => {
      if (index + 1 >= items.length) onDone();
      else {
        setPicked(null);
        setIndex((n) => n + 1);
      }
    }, 700);
  }

  return (
    <div>
      <p className="text-sm text-muted">
        {index + 1} / {items.length} · {item.es}
      </p>
      <div className="mt-4 flex items-center justify-center gap-3">
        <p className="font-display text-4xl tracking-tight">{item.word}</p>
        <SpeakButton text={item.word} />
      </div>
      <div className="mt-8 grid grid-cols-3 gap-3">
        {ARTICLES.map((article) => {
          const show = picked !== null;
          const isRight = article === item.article;
          const isPicked = picked === article;
          return (
            <button
              key={article}
              type="button"
              disabled={picked !== null}
              onClick={() => pick(article)}
              className={cn(
                "min-h-16 rounded-xl border font-display text-2xl",
                "transition-[transform,background-color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
                "active:not-disabled:scale-[0.96]",
                !show && "border-border bg-surface text-fg hover:border-fg/25",
                show && isRight && "border-accent bg-accent text-accent-fg",
                show && isPicked && !isRight && "shake border-fg/40 bg-bg text-muted",
                show && !isPicked && !isRight && "border-border bg-surface text-muted",
              )}
            >
              {article}
            </button>
          );
        })}
      </div>
    </div>
  );
}
