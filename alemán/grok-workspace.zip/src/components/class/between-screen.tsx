import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { GAMES } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";

export function BetweenScreen() {
  const gameIndex = useClassStore((s) => s.gameIndex);
  const pendingBonus = useClassStore((s) => s.pendingBonus);
  const score = useClassStore((s) => s.score);
  const continueFromBetween = useClassStore((s) => s.continueFromBetween);
  const next = pendingBonus
    ? { title: "Relámpago extra", blurb: "Queda tiempo. Otra ronda contra el reloj." }
    : GAMES[gameIndex + 1];

  useEffect(() => {
    const id = window.setTimeout(continueFromBetween, 2200);
    return () => window.clearTimeout(id);
  }, [continueFromBetween]);

  return (
    <div className="mx-auto flex min-h-[60dvh] max-w-md flex-col items-start justify-center px-5 py-10">
      <p className="text-sm text-muted">{score} puntos</p>
      <h2 className="mt-3 font-display text-3xl leading-tight tracking-tight">
        Siguiente
      </h2>
      <p className="mt-2 font-medium text-fg">{next?.title}</p>
      <p className="mt-2 text-pretty text-muted">{next?.blurb}</p>
      <Button className="mt-8" onClick={continueFromBetween}>
        Seguir
      </Button>
    </div>
  );
}
