import { cn } from "@/lib/utils";

export function ChoiceGrid({
  options,
  locked,
  picked,
  correct,
  onPick,
}: {
  options: string[];
  locked: boolean;
  picked: string | null;
  correct: string;
  onPick: (option: string) => void;
}) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      {options.map((option) => {
        const isPicked = picked === option;
        const isRight = option === correct;
        const show = locked;
        return (
          <button
            key={option}
            type="button"
            disabled={locked}
            onClick={() => onPick(option)}
            className={cn(
              "min-h-14 rounded-xl border px-4 py-3 text-left text-base font-medium",
              "transition-[transform,background-color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
              "active:not-disabled:scale-[0.96]",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60",
              !show && "border-border bg-surface text-fg hover:border-fg/25",
              show && isRight && "border-accent bg-accent text-accent-fg",
              show && isPicked && !isRight && "shake border-fg/40 bg-bg text-muted",
              show && !isPicked && !isRight && "border-border bg-surface text-muted",
            )}
          >
            {option}
          </button>
        );
      })}
    </div>
  );
}
