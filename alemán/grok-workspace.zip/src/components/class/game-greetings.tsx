import { useMemo, useState } from "react";
import { greetings } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";
import { speakGerman } from "@/lib/speak";
import { shuffle } from "@/lib/utils";
import { ChoiceGrid } from "@/components/class/choice-grid";
import { SpeakButton } from "@/components/class/speak-button";

export function GameGreetings({ onDone }: { onDone: () => void }) {
  const markAnswer = useClassStore((s) => s.markAnswer);
  const items = useMemo(
    () =>
      shuffle(greetings).map((item) => ({
        ...item,
        options: shuffle(item.options),
      })),
    [],
  );
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const item = items[index];

  if (!item) return null;

  function pick(option: string) {
    if (picked || !item) return;
    const ok = option === item.answer;
    setPicked(option);
    markAnswer(ok, ok ? 10 + useClassStore.getState().streak * 2 : 0);
    if (ok) speakGerman(item.speak);
    window.setTimeout(() => {
      if (index + 1 >= items.length) onDone();
      else {
        setPicked(null);
        setIndex((n) => n + 1);
      }
    }, 700);
  }

  return (
    <div>
      <p className="text-sm text-muted">
        {index + 1} / {items.length}
      </p>
      <div className="mt-3 flex items-start justify-between gap-3">
        <h2 className="font-display text-2xl leading-tight tracking-tight">
          {item.prompt}
        </h2>
        <SpeakButton text={item.speak} />
      </div>
      <div className="mt-6">
        <ChoiceGrid
          options={item.options}
          locked={picked !== null}
          picked={picked}
          correct={item.answer}
          onPick={pick}
        />
      </div>
    </div>
  );
}
