import { Button } from "@/components/ui/button";
import { useClassStore } from "@/lib/class-store";
import { speakGerman } from "@/lib/speak";

export function EndScreen() {
  const score = useClassStore((s) => s.score);
  const correct = useClassStore((s) => s.correct);
  const wrong = useClassStore((s) => s.wrong);
  const bestStreak = useClassStore((s) => s.bestStreak);
  const start = useClassStore((s) => s.start);

  const total = correct + wrong;
  const ratio = total === 0 ? 0 : Math.round((correct / total) * 100);

  return (
    <div className="flex min-h-dvh flex-col bg-fg px-5 py-10 text-bg">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-between">
        <div>
          <p className="text-sm text-bg/60">Clase terminada</p>
          <h1 className="mt-3 font-display text-5xl leading-none tracking-tight">
            Gut gemacht.
          </h1>
          <p className="mt-4 text-bg/75">
            {ratio >= 80
              ? "La racha se nota. Mañana, otra vuelta."
              : "Buen trabajo. Los artículos se quedan con la repetición."}
          </p>
          <dl className="mt-8 grid grid-cols-2 gap-4">
            <Stat label="Puntos" value={String(score)} />
            <Stat label="Aciertos" value={`${correct}/${total || 0}`} />
            <Stat label="Precisión" value={`${ratio}%`} />
            <Stat label="Mejor racha" value={String(bestStreak)} />
          </dl>
        </div>
        <Button
          size="lg"
          className="mt-10 h-14 w-full rounded-xl bg-bg text-fg hover:opacity-95"
          onClick={() => {
            speakGerman("Noch einmal.");
            start();
          }}
        >
          Otra clase
        </Button>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-bg/15 px-4 py-3">
      <dt className="text-xs text-bg/55">{label}</dt>
      <dd className="mt-1 font-display text-2xl tabular-nums">{value}</dd>
    </div>
  );
}
