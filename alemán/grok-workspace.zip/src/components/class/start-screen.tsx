import { Button } from "@/components/ui/button";
import { GAMES } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";
import { speakGerman } from "@/lib/speak";

export function StartScreen() {
  const start = useClassStore((s) => s.start);

  return (
    <div className="flex min-h-dvh flex-col bg-fg px-5 py-10 text-bg">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-between">
        <div>
          <p className="text-sm tracking-wide text-bg/60">A1 · 20 minutos</p>
          <h1 className="mt-3 font-display text-5xl leading-none tracking-tight">
            Klasse 20
          </h1>
          <p className="mt-4 max-w-sm text-pretty text-base leading-relaxed text-bg/75">
            Una clase de alemán hecha de juegos. Instrucciones en español,
            respuestas en alemán. Toca para oír la pronunciación.
          </p>
          <ol className="mt-8 space-y-3">
            {GAMES.map((game, index) => (
              <li key={game.id} className="flex gap-3 text-sm">
                <span className="tabular-nums text-bg/45">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span>
                  <span className="font-medium">{game.title}</span>
                  <span className="block text-bg/55">{game.blurb}</span>
                </span>
              </li>
            ))}
          </ol>
        </div>
        <Button
          size="lg"
          className="mt-10 h-14 w-full rounded-xl bg-bg text-fg hover:opacity-95"
          onClick={() => {
            speakGerman("Guten Tag. Wir lernen Deutsch.");
            start();
          }}
        >
          Empezar la clase
        </Button>
      </div>
    </div>
  );
}
