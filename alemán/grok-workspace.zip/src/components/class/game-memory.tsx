import { useMemo, useState } from "react";
import { memoryPairs } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";
import { speakGerman } from "@/lib/speak";
import { cn, shuffle } from "@/lib/utils";

type Card = {
  id: string;
  pair: string;
  text: string;
  lang: "de" | "es";
  speak?: string;
};

export function GameMemory({ onDone }: { onDone: () => void }) {
  const markAnswer = useClassStore((s) => s.markAnswer);
  const cards = useMemo<Card[]>(() => {
    const deck: Card[] = memoryPairs.flatMap((pair) => [
      {
        id: `${pair.de}-de`,
        pair: pair.de,
        text: pair.de,
        lang: "de",
        speak: pair.speak,
      },
      {
        id: `${pair.de}-es`,
        pair: pair.de,
        text: pair.es,
        lang: "es",
      },
    ]);
    return shuffle(deck);
  }, []);

  const [flipped, setFlipped] = useState<string[]>([]);
  const [matched, setMatched] = useState<string[]>([]);
  const [lock, setLock] = useState(false);
  const [flips, setFlips] = useState(0);

  function turn(card: Card) {
    if (lock) return;
    if (matched.includes(card.pair)) return;
    if (flipped.includes(card.id)) return;
    if (card.speak) speakGerman(card.speak);

    const next = [...flipped, card.id];
    setFlipped(next);
    setFlips((n) => n + 1);

    if (next.length < 2) return;

    const first = cards.find((c) => c.id === next[0]);
    const second = cards.find((c) => c.id === next[1]);
    if (!first || !second) return;

    const ok = first.pair === second.pair && first.lang !== second.lang;
    setLock(true);
    window.setTimeout(() => {
      if (ok) {
        const nextMatched = [...matched, first.pair];
        setMatched(nextMatched);
        markAnswer(true, 16);
        if (nextMatched.length >= memoryPairs.length) onDone();
      } else {
        markAnswer(false, 0);
      }
      setFlipped([]);
      setLock(false);
    }, ok ? 420 : 700);
  }

  return (
    <div>
      <p className="text-sm text-muted">
        {matched.length} / {memoryPairs.length} parejas · {flips} vuelcos
      </p>
      <ul className="mt-4 grid grid-cols-4 gap-2">
        {cards.map((card) => {
          const open = flipped.includes(card.id) || matched.includes(card.pair);
          return (
            <li key={card.id}>
              <button
                type="button"
                onClick={() => turn(card)}
                disabled={open && matched.includes(card.pair)}
                className={cn(
                  "flex min-h-20 w-full items-center justify-center rounded-lg border px-1 text-center text-xs font-medium sm:min-h-24 sm:text-sm",
                  "transition-[transform,background-color,border-color] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
                  "active:not-disabled:scale-[0.96]",
                  open
                    ? matched.includes(card.pair)
                      ? "border-accent bg-accent text-accent-fg"
                      : "border-fg/20 bg-surface text-fg"
                    : "border-border bg-fg text-bg",
                )}
              >
                {open ? card.text : "DE"}
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
