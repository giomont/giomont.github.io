import { Pause, Play } from "lucide-react";
import { CLASS_SECONDS, GAMES } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";
import { cn, formatClock } from "@/lib/utils";

export function Hud() {
  const elapsed = useClassStore((s) => s.elapsed);
  const score = useClassStore((s) => s.score);
  const streak = useClassStore((s) => s.streak);
  const gameIndex = useClassStore((s) => s.gameIndex);
  const paused = useClassStore((s) => s.paused);
  const togglePause = useClassStore((s) => s.togglePause);
  const left = CLASS_SECONDS - elapsed;
  const game = GAMES[Math.min(gameIndex, GAMES.length - 1)];

  return (
    <header className="sticky top-0 z-20 border-b border-border bg-bg/95 px-4 py-3 backdrop-blur-sm">
      <div className="mx-auto flex max-w-lg items-center gap-3">
        <button
          type="button"
          onClick={togglePause}
          aria-label={paused ? "Seguir" : "Pausa"}
          className="grid size-11 shrink-0 place-items-center rounded-full border border-border bg-surface text-fg transition-[transform,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:border-fg/25 active:scale-[0.96]"
        >
          {paused ? (
            <Play className="size-4" strokeWidth={1.75} />
          ) : (
            <Pause className="size-4" strokeWidth={1.75} />
          )}
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-medium uppercase tracking-wide text-muted">
            {game?.title}
          </p>
          <div className="mt-1.5 flex gap-1">
            {GAMES.map((item, index) => (
              <span
                key={item.id}
                className={cn(
                  "h-1 flex-1 rounded-full",
                  index < gameIndex
                    ? "bg-accent"
                    : index === gameIndex
                      ? "bg-fg"
                      : "bg-border",
                )}
              />
            ))}
          </div>
        </div>
        <div className="text-right">
          <p className="font-display text-xl tabular-nums leading-none text-fg">
            {formatClock(left)}
          </p>
          <p className="mt-1 text-xs tabular-nums text-muted">
            {score} pts
            {streak > 1 ? ` · racha ${streak}` : ""}
          </p>
        </div>
      </div>
    </header>
  );
}
