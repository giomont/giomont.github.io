import { Volume2 } from "lucide-react";
import { speakGerman } from "@/lib/speak";

export function SpeakButton({ text, label }: { text: string; label?: string }) {
  return (
    <button
      type="button"
      onClick={() => speakGerman(text)}
      aria-label={label ?? `Escuchar ${text}`}
      className="inline-flex size-11 items-center justify-center rounded-full border border-border bg-surface text-fg transition-[transform,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:border-fg/25 active:scale-[0.96]"
    >
      <Volume2 className="size-4" strokeWidth={1.75} />
    </button>
  );
}
