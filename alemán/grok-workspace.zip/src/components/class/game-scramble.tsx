import { useMemo, useState } from "react";
import { scrambleItems } from "@/lib/class-data";
import { useClassStore } from "@/lib/class-store";
import { speakGerman } from "@/lib/speak";
import { cn, shuffle } from "@/lib/utils";
import { SpeakButton } from "@/components/class/speak-button";

export function GameScramble({ onDone }: { onDone: () => void }) {
  const markAnswer = useClassStore((s) => s.markAnswer);
  const items = useMemo(() => shuffle(scrambleItems), []);
  const [index, setIndex] = useState(0);
  const item = items[index];
  const [pool, setPool] = useState<string[]>(() =>
    item ? scramblePool(item.words) : [],
  );
  const [built, setBuilt] = useState<string[]>([]);
  const [status, setStatus] = useState<"play" | "ok" | "bad">("play");

  if (!item) return null;

  function load(nextIndex: number) {
    const next = items[nextIndex];
    if (!next) return;
    setIndex(nextIndex);
    setBuilt([]);
    setPool(scramblePool(next.words));
    setStatus("play");
  }

  function tapPool(word: string, at: number) {
    if (status !== "play" || !item) return;
    const nextBuilt = [...built, word];
    const nextPool = pool.filter((_, i) => i !== at);
    setBuilt(nextBuilt);
    setPool(nextPool);
    if (nextPool.length > 0) return;

    const ok = nextBuilt.join(" ") === item.words.join(" ");
    setStatus(ok ? "ok" : "bad");
    markAnswer(ok, ok ? 18 : 0);
    if (ok) speakGerman(item.speak);
    window.setTimeout(() => {
      if (index + 1 >= items.length) onDone();
      else load(index + 1);
    }, ok ? 800 : 900);
  }

  function undo() {
    if (status !== "play" || built.length === 0) return;
    const word = built[built.length - 1];
    if (!word) return;
    setBuilt(built.slice(0, -1));
    setPool([...pool, word]);
  }

  return (
    <div>
      <p className="text-sm text-muted">
        {index + 1} / {items.length}
      </p>
      <div className="mt-3 flex items-start justify-between gap-3">
        <h2 className="font-display text-2xl leading-tight tracking-tight">
          {item.es}
        </h2>
        <SpeakButton text={item.speak} />
      </div>

      <div
        className={cn(
          "mt-6 flex min-h-16 flex-wrap content-start gap-2 rounded-xl border bg-surface px-3 py-3",
          status === "ok" && "border-accent",
          status === "bad" && "shake border-fg/40",
          status === "play" && "border-border",
        )}
      >
        {built.length === 0 ? (
          <span className="text-sm text-subtle">Toca las palabras abajo</span>
        ) : (
          built.map((word, i) => (
            <span
              key={`${word}-${i}`}
              className="rounded-md bg-bg px-2.5 py-1.5 text-sm font-medium text-fg"
            >
              {word}
            </span>
          ))
        )}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {pool.map((word, i) => (
          <button
            key={`${word}-${i}`}
            type="button"
            onClick={() => tapPool(word, i)}
            disabled={status !== "play"}
            className="min-h-11 rounded-md border border-border bg-surface px-3 text-sm font-medium text-fg transition-[transform,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:border-fg/25 active:not-disabled:scale-[0.96]"
          >
            {word}
          </button>
        ))}
      </div>

      <button
        type="button"
        onClick={undo}
        disabled={built.length === 0 || status !== "play"}
        className="mt-4 text-sm text-muted underline-offset-4 hover:text-fg hover:underline disabled:opacity-40"
      >
        Deshacer
      </button>
    </div>
  );
}

function scramblePool(words: string[]) {
  let next = shuffle(words);
  let guard = 0;
  while (next.join(" ") === words.join(" ") && words.length > 1 && guard < 8) {
    next = shuffle(words);
    guard += 1;
  }
  return next;
}
