export const CLASS_SECONDS = 20 * 60;

export type GameId = "greetings" | "memory" | "gender" | "scramble" | "blitz";

export type QuizItem = {
  prompt: string;
  options: string[];
  answer: string;
  speak: string;
};

export type MemoryPair = { de: string; es: string; speak: string };

export type GenderItem = {
  word: string;
  article: "der" | "die" | "das";
  es: string;
};

export type ScrambleItem = {
  words: string[];
  es: string;
  speak: string;
};

export const GAMES: {
  id: GameId;
  title: string;
  blurb: string;
  minutes: number;
}[] = [
  {
    id: "greetings",
    title: "Saludos relámpago",
    blurb: "Elige el saludo correcto. Toca el altavoz para oírlo.",
    minutes: 3,
  },
  {
    id: "memory",
    title: "Memoria",
    blurb: "Empareja alemán y español. Menos vuelcos, más puntos.",
    minutes: 5,
  },
  {
    id: "gender",
    title: "Der, die, das",
    blurb: "Toca el artículo. Racha = extra.",
    minutes: 4,
  },
  {
    id: "scramble",
    title: "Ordena la frase",
    blurb: "Toca las palabras en orden. Una frase de verdad.",
    minutes: 4,
  },
  {
    id: "blitz",
    title: "Relámpago",
    blurb: "Sesenta segundos. Español → alemán. ¡Rápido!",
    minutes: 3,
  },
];

export const greetings: QuizItem[] = [
  {
    prompt: "¿Cómo se dice «hola»?",
    options: ["Hallo", "Tschüss", "Bitte", "Nein"],
    answer: "Hallo",
    speak: "Hallo",
  },
  {
    prompt: "Por la mañana, al llegar:",
    options: ["Guten Morgen", "Gute Nacht", "Bitte schön", "Auf Wiedersehen"],
    answer: "Guten Morgen",
    speak: "Guten Morgen",
  },
  {
    prompt: "Durante el día, más formal:",
    options: ["Guten Tag", "Guten Appetit", "Entschuldigung", "Hallo"],
    answer: "Guten Tag",
    speak: "Guten Tag",
  },
  {
    prompt: "Al atardecer:",
    options: ["Guten Abend", "Guten Morgen", "Willkommen", "Ja bitte"],
    answer: "Guten Abend",
    speak: "Guten Abend",
  },
  {
    prompt: "Despedida informal:",
    options: ["Tschüss", "Guten Tag", "Danke", "Bitte"],
    answer: "Tschüss",
    speak: "Tschüss",
  },
  {
    prompt: "¿Cómo estás?",
    options: ["Wie geht's?", "Wer bist du?", "Wo bist du?", "Was ist das?"],
    answer: "Wie geht's?",
    speak: "Wie geht's?",
  },
  {
    prompt: "«Muy bien, gracias»",
    options: ["Gut, danke", "Nein danke", "Sehr schlecht", "Noch mal"],
    answer: "Gut, danke",
    speak: "Gut, danke",
  },
  {
    prompt: "«Por favor»",
    options: ["Bitte", "Danke", "Gern", "Hilfe"],
    answer: "Bitte",
    speak: "Bitte",
  },
  {
    prompt: "«Gracias»",
    options: ["Danke", "Bitte", "Hallo", "Oder"],
    answer: "Danke",
    speak: "Danke",
  },
  {
    prompt: "«Sí» y «no»",
    options: ["Ja / Nein", "Und / Oder", "Hier / Da", "Ein / Eine"],
    answer: "Ja / Nein",
    speak: "Ja. Nein.",
  },
];

export const memoryPairs: MemoryPair[] = [
  { de: "Hallo", es: "Hola", speak: "Hallo" },
  { de: "Danke", es: "Gracias", speak: "Danke" },
  { de: "Bitte", es: "Por favor", speak: "Bitte" },
  { de: "Wasser", es: "Agua", speak: "Wasser" },
  { de: "Brot", es: "Pan", speak: "Brot" },
  { de: "Buch", es: "Libro", speak: "Buch" },
  { de: "Freund", es: "Amigo", speak: "Freund" },
  { de: "Haus", es: "Casa", speak: "Haus" },
];

export const genderItems: GenderItem[] = [
  { word: "Tisch", article: "der", es: "mesa" },
  { word: "Stuhl", article: "der", es: "silla" },
  { word: "Hund", article: "der", es: "perro" },
  { word: "Apfel", article: "der", es: "manzana" },
  { word: "Lampe", article: "die", es: "lámpara" },
  { word: "Tür", article: "die", es: "puerta" },
  { word: "Katze", article: "die", es: "gato" },
  { word: "Banane", article: "die", es: "plátano" },
  { word: "Buch", article: "das", es: "libro" },
  { word: "Fenster", article: "das", es: "ventana" },
  { word: "Haus", article: "das", es: "casa" },
  { word: "Auto", article: "das", es: "coche" },
];

export const scrambleItems: ScrambleItem[] = [
  {
    words: ["Ich", "heiße", "Maria"],
    es: "Me llamo Maria",
    speak: "Ich heiße Maria",
  },
  {
    words: ["Wie", "geht", "es", "dir?"],
    es: "¿Cómo te va?",
    speak: "Wie geht es dir?",
  },
  {
    words: ["Ich", "komme", "aus", "Spanien"],
    es: "Vengo de España",
    speak: "Ich komme aus Spanien",
  },
  {
    words: ["Das", "ist", "ein", "Buch"],
    es: "Eso es un libro",
    speak: "Das ist ein Buch",
  },
  {
    words: ["Wir", "lernen", "Deutsch"],
    es: "Aprendemos alemán",
    speak: "Wir lernen Deutsch",
  },
  {
    words: ["Guten", "Morgen,", "Klasse"],
    es: "Buenos días, clase",
    speak: "Guten Morgen, Klasse",
  },
];

export const blitzItems: QuizItem[] = [
  { prompt: "uno", options: ["eins", "zwei", "drei", "vier"], answer: "eins", speak: "eins" },
  { prompt: "dos", options: ["zwei", "eins", "zehn", "null"], answer: "zwei", speak: "zwei" },
  { prompt: "tres", options: ["drei", "frei", "zwei", "neu"], answer: "drei", speak: "drei" },
  { prompt: "rojo", options: ["rot", "grün", "blau", "gelb"], answer: "rot", speak: "rot" },
  { prompt: "azul", options: ["blau", "braun", "weiß", "rot"], answer: "blau", speak: "blau" },
  { prompt: "verde", options: ["grün", "grau", "gelb", "rot"], answer: "grün", speak: "grün" },
  { prompt: "casa", options: ["Haus", "Maus", "Baum", "Raum"], answer: "Haus", speak: "Haus" },
  { prompt: "libro", options: ["Buch", "Tuch", "Bauch", "Besuch"], answer: "Buch", speak: "Buch" },
  { prompt: "agua", options: ["Wasser", "Wetter", "Wein", "Brot"], answer: "Wasser", speak: "Wasser" },
  { prompt: "pan", options: ["Brot", "Brotchen", "Butter", "Bier"], answer: "Brot", speak: "Brot" },
  { prompt: "perro", options: ["Hund", "Hand", "Huhn", "Hut"], answer: "Hund", speak: "Hund" },
  { prompt: "gato", options: ["Katze", "Karte", "Tasse", "Kasse"], answer: "Katze", speak: "Katze" },
  { prompt: "madre", options: ["Mutter", "Vater", "Tochter", "Sohn"], answer: "Mutter", speak: "Mutter" },
  { prompt: "padre", options: ["Vater", "Bruder", "Onkel", "Freund"], answer: "Vater", speak: "Vater" },
  { prompt: "yo", options: ["ich", "du", "er", "wir"], answer: "ich", speak: "ich" },
  { prompt: "tú", options: ["du", "ihr", "sie", "es"], answer: "du", speak: "du" },
  { prompt: "sí", options: ["ja", "nein", "doch", "so"], answer: "ja", speak: "ja" },
  { prompt: "no", options: ["nein", "kein", "nie", "nur"], answer: "nein", speak: "nein" },
  { prompt: "gracias", options: ["Danke", "Bitte", "Gern", "Hallo"], answer: "Danke", speak: "Danke" },
  { prompt: "adiós (informal)", options: ["Tschüss", "Bitte", "Willkommen", "Genau"], answer: "Tschüss", speak: "Tschüss" },
];
