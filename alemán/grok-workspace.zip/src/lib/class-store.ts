import { create } from "zustand";
import { CLASS_SECONDS, GAMES } from "@/lib/class-data";

export type Status = "idle" | "playing" | "between" | "done";

type ClassState = {
  status: Status;
  gameIndex: number;
  round: number;
  pendingBonus: boolean;
  score: number;
  streak: number;
  bestStreak: number;
  correct: number;
  wrong: number;
  elapsed: number;
  paused: boolean;
  start: () => void;
  reset: () => void;
  togglePause: () => void;
  tick: (dt: number) => void;
  markAnswer: (ok: boolean, points: number) => void;
  completeGame: () => void;
  continueFromBetween: () => void;
  finish: () => void;
};

const initial = {
  status: "idle" as Status,
  gameIndex: 0,
  round: 0,
  pendingBonus: false,
  score: 0,
  streak: 0,
  bestStreak: 0,
  correct: 0,
  wrong: 0,
  elapsed: 0,
  paused: false,
};

export const useClassStore = create<ClassState>((set, get) => ({
  ...initial,
  start: () =>
    set({
      ...initial,
      status: "playing",
    }),
  reset: () => set({ ...initial }),
  togglePause: () => {
    const { status, paused } = get();
    if (status === "idle" || status === "done") return;
    set({ paused: !paused });
  },
  tick: (dt) => {
    const { status, paused, elapsed } = get();
    if (paused || status === "idle" || status === "done" || status === "between") {
      return;
    }
    const next = elapsed + dt;
    if (next >= CLASS_SECONDS) {
      set({ elapsed: CLASS_SECONDS, status: "done", paused: false });
      return;
    }
    set({ elapsed: next });
  },
  markAnswer: (ok, points) =>
    set((state) => {
      const streak = ok ? state.streak + 1 : 0;
      return {
        score: Math.max(0, state.score + points),
        streak,
        bestStreak: Math.max(state.bestStreak, streak),
        correct: state.correct + (ok ? 1 : 0),
        wrong: state.wrong + (ok ? 0 : 1),
      };
    }),
  completeGame: () => {
    const { elapsed, gameIndex } = get();
    const left = CLASS_SECONDS - elapsed;
    if (left <= 8) {
      set({ status: "done", paused: false, pendingBonus: false });
      return;
    }
    if (gameIndex >= GAMES.length - 1) {
      set({ status: "between", paused: false, pendingBonus: true });
      return;
    }
    set({ status: "between", paused: false, pendingBonus: false });
  },
  continueFromBetween: () => {
    const { gameIndex, pendingBonus, round, elapsed, status } = get();
    if (status !== "between") return;
    if (elapsed >= CLASS_SECONDS) {
      set({ status: "done", pendingBonus: false });
      return;
    }
    if (pendingBonus) {
      set({
        status: "playing",
        pendingBonus: false,
        round: round + 1,
        gameIndex: GAMES.length - 1,
      });
      return;
    }
    set({ status: "playing", gameIndex: gameIndex + 1 });
  },
  finish: () => set({ status: "done", paused: false }),
}));
